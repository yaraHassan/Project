<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <title>Purchase successful</title>
</head>
<body>
      <h1>Thank you for purchasing</h1>
      <p>
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium saepe est, debitis aspernatur voluptates dolorem! Laudantium delectus recusandae, aliquam. Illum sit repellat culpa hic eos sint ipsum quibusdam unde necessitatibus!
      </p>
</body>
</html>